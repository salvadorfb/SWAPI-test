import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

@Injectable()
export class DataService {
   DataArray = [];

   checkMe: any;

  constructor(private _http: Http) { }

   public LoadData()
   {
    return this._http.get('http://localhost:8080/personajes?ordernar=nombre')
     .map(res => {
          this.checkMe = res;

          if (this.checkMe._body !== '0') {
             return res.json();
            }
      });
   }
}